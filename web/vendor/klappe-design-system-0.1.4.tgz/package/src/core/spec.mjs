// DESIGN.md frontmatter -> the design spec every output is generated from (spec.json, CSS variables, Tailwind theme, MUI theme).
// Plain ESM with no Node imports: the CLI, the hub and browsers all use it.

export const M3_ROLES = [
  'primary', 'on-primary', 'primary-container', 'on-primary-container',
  'secondary', 'on-secondary', 'secondary-container', 'on-secondary-container',
  'tertiary', 'on-tertiary', 'tertiary-container', 'on-tertiary-container',
  'error', 'on-error', 'error-container', 'on-error-container',
  'background', 'on-background',
  'surface', 'on-surface', 'surface-variant', 'on-surface-variant',
  'surface-container-lowest', 'surface-container-low', 'surface-container', 'surface-container-high', 'surface-container-highest',
  'outline', 'outline-variant', 'inverse-surface', 'inverse-on-surface', 'inverse-primary', 'scrim', 'shadow',
]

// Material UI component a DESIGN.md component renders as, unless it names one with `material:`.
export function guessMaterial(name) {
  const n = name.toLowerCase()
  if (/button|cta/.test(n)) return /outline/.test(n) ? 'Button:outlined' : /text|ghost/.test(n) ? 'Button:text' : 'Button:contained'
  if (/link/.test(n)) return 'Link'
  if (/input|field|textarea/.test(n)) return 'TextField:outlined'
  if (/tab/.test(n)) return 'Tab'
  if (/chip|tag|pill|badge/.test(n)) return 'Chip'
  if (/checkbox/.test(n)) return 'Checkbox'
  if (/switch|toggle/.test(n)) return 'Switch'
  if (/footer|header|app-?bar|nav-?bar/.test(n)) return 'AppBar'
  if (/card|document|panel|finding|art/.test(n)) return 'Card'
  if (/list|row|item/.test(n)) return 'ListItemButton'
  return 'none'
}

const STATE = /-(hover|active|focus|selected|disabled|pressed)$/

// Component keys that describe a component rather than style it. They never reach CSS.
export const COMPONENT_META_KEYS = ['material', 'label', 'selector', 'scope', 'material-default', 'materialDefault', 'description', 'note', 'notes']

// A component styles every instance of its Material UI component (theme styleOverrides) only when it opts in with
// `scope: global` or `material-default: true`. Otherwise it styles only what renders through Part or componentSx.
const isGlobal = (props) => {
  const flag = props['material-default'] ?? props.materialDefault
  return String(props.scope ?? '').toLowerCase() === 'global' || flag === true || String(flag).toLowerCase() === 'true'
}

// Which Material role a component property should follow when its color maps to several roles.
const ROLE_PREFERENCE = {
  text: ['on-surface', 'on-background', 'on-surface-variant', 'on-primary', 'on-primary-container', 'on-secondary', 'on-secondary-container', 'on-tertiary', 'on-tertiary-container', 'on-error', 'on-error-container', 'inverse-on-surface'],
  border: ['outline', 'outline-variant'],
  fill: ['surface', 'background', 'primary', 'secondary', 'tertiary', 'error', 'primary-container', 'secondary-container', 'tertiary-container', 'error-container', 'surface-variant', 'surface-container-lowest', 'surface-container-low', 'surface-container', 'surface-container-high', 'surface-container-highest', 'inverse-surface', 'inverse-primary'],
}
const propKind = (prop) => {
  if (/border|outline|stroke|divider|rule/i.test(prop)) return 'border'
  if (/background|fill|^bg/i.test(prop)) return 'fill'
  if (/^(color|textColor|caretColor|accentColor|textDecorationColor)$/.test(prop)) return 'text'
  return 'fill'
}

// Resolve {group.name} references; a reference to a group (typography.body) resolves to an object.
function resolver(front) {
  const get = (path) => path.split('.').reduce((n, k) => (n && typeof n === 'object' ? n[k] : undefined), front)
  const resolve = (value, seen = new Set()) => {
    if (typeof value !== 'string') return value
    const whole = value.match(/^\{([^}]+)\}$/)
    if (whole) {
      if (seen.has(whole[1])) return value
      const hit = get(whole[1])
      if (hit === undefined) return value
      if (hit && typeof hit === 'object') return Object.fromEntries(Object.entries(hit).map(([k, v]) => [k, resolve(v, new Set([...seen, whole[1]]))]))
      return resolve(String(hit), new Set([...seen, whole[1]]))
    }
    return value.replace(/\{([^}]+)\}/g, (all, p) => {
      const hit = get(p)
      return hit === undefined || typeof hit === 'object' ? all : String(resolve(String(hit), new Set([...seen, p])))
    })
  }
  return resolve
}

const mapValues = (o, f) => Object.fromEntries(Object.entries(o || {}).map(([k, v]) => [k, f(v, k)]))

/**
 * @param {Record<string, any>} front  parsed DESIGN.md frontmatter
 * @param {{ cssVars?: Map<string,string>, colorRefs?: 'var' | 'value', spacingUnit?: string | number }} [opts]
 *   cssVars: custom properties found in the project's CSS, to resolve var() aliases.
 *   colorRefs: 'var' (default) writes component color references as var(--ds-role-*) so they follow dark mode;
 *   'value' writes the resolved value.
 *   spacingUnit: the theme spacing unit (a length or a spacing token name), overriding DESIGN.md spacing.unit.
 */
export function buildSpec(front, opts = {}) {
  const vars = opts.cssVars ?? new Map()
  const colorRefs = opts.colorRefs ?? 'var'
  const unvar = (v, seen = new Set()) => (typeof v === 'string'
    ? v.replace(/var\((--[a-zA-Z0-9-]+)(?:,\s*([^)]+))?\)/g, (all, n, fb) => {
      if (seen.has(n)) return all
      const hit = vars.get(n) ?? fb
      return hit ? unvar(hit, new Set([...seen, n])) : all
    })
    : v)
  const resolve = resolver(front)
  const value = (v) => {
    const r = resolve(v)
    return r && typeof r === 'object' ? mapValues(r, (x) => unvar(x)) : unvar(r)
  }
  const colors = mapValues(front.colors, (v) => String(value(v)))
  const pickRoles = (src) => {
    if (src && typeof src === 'object') return mapValues(src, (v) => String(value(v)))
    return Object.fromEntries(Object.entries(colors).filter(([k]) => M3_ROLES.includes(k)))
  }
  const typography = mapValues(front.typography, (t) => mapValues(t, (v) => (typeof v === 'number' ? v : String(value(v)))))
  const roles = pickRoles(front.roles)

  // {colors.x} and {roles.x} in a component become var(--ds-role-*) (or var(--ds-color-*)) with the value as fallback,
  // so component styles follow the color scheme. A color follows the role that DESIGN.md maps to it.
  const rolesOfColor = new Map()
  if (front.roles && typeof front.roles === 'object') {
    for (const [role, ref] of Object.entries(front.roles)) {
      const m = typeof ref === 'string' && ref.match(/^\{colors\.([^}]+)\}$/)
      if (m) rolesOfColor.set(m[1], [...(rolesOfColor.get(m[1]) ?? []), role])
    }
  } else for (const k of Object.keys(roles)) rolesOfColor.set(k, [k])
  const colorVar = (group, name, prop) => {
    if (group === 'roles') return roles[name] !== undefined ? `var(--ds-role-${kebab(name)}, ${roles[name]})` : null
    if (colors[name] === undefined) return null
    const candidates = rolesOfColor.get(name) ?? []
    const role = ROLE_PREFERENCE[propKind(prop)].find((r) => candidates.includes(r)) ?? candidates.find((r) => !r.startsWith('on-')) ?? candidates[0]
    return role ? `var(--ds-role-${kebab(role)}, ${colors[name]})` : `var(--ds-color-${kebab(name)}, ${colors[name]})`
  }
  const styleValue = (v, prop) => {
    if (colorRefs !== 'var' || typeof v !== 'string') return value(v)
    const held = []
    const marked = v.replace(/\{(colors|roles)\.([^}]+)\}/g, (all, group, name) => {
      const out = colorVar(group, name, prop)
      if (!out) return all
      held.push(out)
      return `\u0000${held.length - 1}\u0000`
    })
    if (!held.length) return value(v)
    return String(value(marked)).replace(/\u0000(\d+)\u0000/g, (all, i) => held[Number(i)])
  }

  const components = {}
  for (const [name, props] of Object.entries(front.components || {})) {
    const raw = mapValues(props, (v) => String(v))
    const style = Object.fromEntries(Object.entries(raw).filter(([k]) => !COMPONENT_META_KEYS.includes(k)))
    components[name] = {
      material: raw.material || guessMaterial(name.replace(STATE, '')),
      label: raw.label || null,
      selector: raw.selector || null,
      global: isGlobal(props || {}),
      state: name.match(STATE)?.[1] ?? null,
      base: STATE.test(name) ? name.replace(STATE, '') : null,
      raw: style,
      style: mapValues(style, (v, k) => styleValue(v, k)),
    }
  }

  // The theme spacing unit: the config's spacingUnit, else DESIGN.md spacing.unit (a length or the name of another
  // spacing token). Without either the theme uses spacing.base, then 8px.
  const { unit: unitToken, ...spacingTokens } = front.spacing || {}
  const spacing = mapValues(spacingTokens, (v) => String(value(v)))
  const unitRaw = opts.spacingUnit ?? unitToken
  let spacingUnit = null
  if (unitRaw !== undefined && unitRaw !== null && unitRaw !== '') {
    const u = typeof unitRaw === 'number' ? `${unitRaw}px` : String(unitRaw)
    spacingUnit = u in spacing ? spacing[u] : String(value(u))
  }
  return {
    $schema: 'design-spec/1',
    name: front.name ?? null,
    description: front.description ?? null,
    roles,
    rolesDark: front.rolesDark ? pickRoles(front.rolesDark) : null,
    colors,
    typography,
    spacing,
    spacingUnit,
    rounded: mapValues(front.rounded, (v) => String(value(v))),
    components,
  }
}

// What a project's spec still lacks before the shared components can theme it properly.
export function specWarnings(spec, front) {
  const w = []
  for (const role of ['primary', 'on-primary', 'surface', 'on-surface']) if (!spec.roles[role]) w.push(`No ${role} role. Add roles.${role} to DESIGN.md (for example "{colors.pine}").`)
  const scan = (o, path) => {
    for (const [k, v] of Object.entries(o || {})) {
      if (v && typeof v === 'object') scan(v, `${path}.${k}`)
      else if (/var\(--/.test(String(v))) w.push(`${path}.${k} is a var() alias. Write the value itself so every app gets it.`)
    }
  }
  for (const g of ['colors', 'roles', 'typography', 'spacing', 'rounded']) scan(front[g], g)
  return w
}

// ---- outputs -------------------------------------------------------------------------------------

const kebab = (s) => String(s).replace(/([a-z0-9])([A-Z])/g, '$1-$2').replace(/[^a-zA-Z0-9]+/g, '-').toLowerCase()
const TYPE_PROPS = { fontFamily: 'family', fontSize: 'size', fontWeight: 'weight', lineHeight: 'line-height', letterSpacing: 'letter-spacing' }
const HEADER = (what) => `/* Generated by @klappe/design-system from DESIGN.md (${what}). Edit DESIGN.md or the hub, then run ds sync. */\n`

// Every token as a CSS custom property: --ds-color-*, --ds-role-*, --ds-font-<style>-*, --ds-space-*, --ds-radius-*.
export function cssVariables(spec) {
  const lines = []
  for (const [k, v] of Object.entries(spec.colors)) lines.push(`  --ds-color-${kebab(k)}: ${v};`)
  for (const [k, v] of Object.entries(spec.roles)) lines.push(`  --ds-role-${kebab(k)}: ${v};`)
  for (const [name, t] of Object.entries(spec.typography)) {
    for (const [p, v] of Object.entries(t)) if (TYPE_PROPS[p]) lines.push(`  --ds-font-${kebab(name)}-${TYPE_PROPS[p]}: ${v};`)
  }
  for (const [k, v] of Object.entries(spec.spacing)) lines.push(`  --ds-space-${kebab(k)}: ${v};`)
  for (const [k, v] of Object.entries(spec.rounded)) lines.push(`  --ds-radius-${kebab(k)}: ${v};`)
  let css = `${HEADER('tokens')}:root {\n${lines.join('\n')}\n}\n`
  if (spec.rolesDark) {
    const dark = Object.entries(spec.rolesDark).map(([k, v]) => `  --ds-role-${kebab(k)}: ${v};`).join('\n')
    css += `\n@media (prefers-color-scheme: dark) {\n  :root:not([data-theme='light']) {\n${dark.replace(/^/gm, '  ')}\n  }\n}\n\n[data-theme='dark'] {\n${dark}\n}\n`
  }
  return css
}

// Tailwind v4 theme that points at the CSS variables, so utilities (bg-primary, text-display, p-regular) follow the tokens.
export function tailwindTheme(spec) {
  const lines = []
  for (const k of Object.keys(spec.roles)) lines.push(`  --color-${kebab(k)}: var(--ds-role-${kebab(k)});`)
  for (const k of Object.keys(spec.colors)) if (!(k in spec.roles)) lines.push(`  --color-${kebab(k)}: var(--ds-color-${kebab(k)});`)
  for (const [name, t] of Object.entries(spec.typography)) {
    const n = kebab(name)
    if (t.fontFamily) lines.push(`  --font-${n}: var(--ds-font-${n}-family);`)
    if (t.fontSize) {
      lines.push(`  --text-${n}: var(--ds-font-${n}-size);`)
      if (t.lineHeight) lines.push(`  --text-${n}--line-height: var(--ds-font-${n}-line-height);`)
      if (t.letterSpacing) lines.push(`  --text-${n}--letter-spacing: var(--ds-font-${n}-letter-spacing);`)
      if (t.fontWeight) lines.push(`  --text-${n}--font-weight: var(--ds-font-${n}-weight);`)
    }
  }
  for (const k of Object.keys(spec.spacing)) lines.push(`  --spacing-${kebab(k)}: var(--ds-space-${kebab(k)});`)
  for (const k of Object.keys(spec.rounded)) lines.push(`  --radius-${kebab(k)}: var(--ds-radius-${kebab(k)});`)
  return `${HEADER('Tailwind theme')}@theme inline {\n${lines.join('\n')}\n}\n`
}

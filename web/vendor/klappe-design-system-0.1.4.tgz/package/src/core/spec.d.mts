import type { DesignSpec } from './types.mjs'
export interface BuildSpecOptions {
  /** Custom properties found in the project's CSS, to resolve var() aliases. */
  cssVars?: Map<string, string>
  /** 'var' (default): component color references become var(--ds-role-*) so they follow dark mode. 'value': the resolved value. */
  colorRefs?: 'var' | 'value'
  /** Theme spacing unit (a length or a spacing token name); overrides DESIGN.md spacing.unit. */
  spacingUnit?: string | number
}
export declare const M3_ROLES: string[]
export declare const COMPONENT_META_KEYS: string[]
export declare function guessMaterial(name: string): string
export declare function buildSpec(front: Record<string, any>, opts?: BuildSpecOptions): DesignSpec
export declare function specWarnings(spec: DesignSpec, front: Record<string, any>): string[]
export declare function cssVariables(spec: DesignSpec): string
export declare function tailwindTheme(spec: DesignSpec): string

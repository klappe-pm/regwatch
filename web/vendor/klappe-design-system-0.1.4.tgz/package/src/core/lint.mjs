// What `ds lint` reports: hardcoded colors and copy in source files. Plain ESM with no Node imports so it can be tested
// and reused; the CLI walks the files and feeds each one in.

export const LINT_EXTENSIONS = /\.(tsx|jsx|ts|js|mjs|cjs|css|scss|html|htm)$/

// A hex color: 3, 4, 6 or 8 hex digits, not glued to other identifier characters (#add-rule, #fade-in, #abcdefg).
const HEX = /#(?:[0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{3,4})(?![\w-])/g
const FUNC = /\brgba?\(\s*\d/g

// Places a #token is a link, id or selector rather than a color.
const NOT_COLOR_BEFORE = [
  /\b(?:href|xlink:href|src|action|for|id|name|to|hash|target|aria-[\w-]+)\s*=\s*\{?\s*["'`]?[^"'`\s]*$/i, // href="#add", to={'#top'}
  /(?:querySelector(?:All)?|closest|matches|getElementById|scrollIntoView|\$\$?)\(\s*["'`][^"'`]*$/, // querySelector('#add')
  /(?:location\.)?hash\s*(?:===?|!==?)\s*["'`]$/, // location.hash === '#add'
  /url\(\s*["']?$/, // url(#gradient) in SVG
]
// A hex in a color context: a declaration or property value, an attribute or assignment, a string, a list or call argument.
const COLOR_BEFORE = [/:[^;{}]*$/, /\([^()]*$/, /=\s*\{?\s*["'`]?\s*$/, /["'`]\s*$/, /,\s*$/]
// Followed by `{` before any `;` or quote: a CSS selector (`#fade {`, `a:hover #add {`).
const SELECTOR_AFTER = /^[^;{}"'`]*\{/

export function colorFindings(line) {
  const out = []
  for (const m of line.matchAll(HEX)) {
    const before = line.slice(0, m.index)
    const after = line.slice(m.index + m[0].length)
    if (/[\w&#$/.-]$/.test(before)) continue // foo#abc, &#123;, /page#top, a.#b
    if (NOT_COLOR_BEFORE.some((r) => r.test(before))) continue
    if (!COLOR_BEFORE.some((r) => r.test(before))) continue
    if (SELECTOR_AFTER.test(after)) continue
    out.push(m[0])
  }
  for (const m of line.matchAll(FUNC)) out.push(m[0])
  return out
}

// JSX text between a tag's `>` and the next `<`. The `>` must close a tag (not `=>`, `->`, `>=`, `>>` or a comparison
// with a space before it), and a `<` glued to an identifier (Promise<T>, get<T>(), Array<string>) is a generic, not a tag.
const JSX_TEXT = /(?<=[\w"'}\/\]])>(?![=>])\s*([A-Za-z][^<>{}]*[A-Za-z.!?])(\s*)<(?!=)/g

export function copyFindings(line) {
  const out = []
  for (const m of line.matchAll(JSX_TEXT)) {
    const text = m[1]
    const next = line[m.index + m[0].length] ?? ''
    if (!m[2] && /[\w$]$/.test(text) && next !== '/') continue // generic: Promise<T>, Map<K, V>
    if (/=>|;|\)\s*\{|\bextends\b|\bkeyof\b/.test(text)) continue // a line of code, not copy
    out.push(text.slice(0, 60))
  }
  return out
}

const COMMENT = /^\s*(\/\/|\*|\/\*|<!--)/

// text: a file's contents; file: its path (the extension decides which checks run).
export function lintSource(text, file) {
  const problems = []
  const jsx = /\.(tsx|jsx)$/.test(file)
  text.split('\n').forEach((line, i) => {
    if (COMMENT.test(line)) return
    for (const c of colorFindings(line)) problems.push({ line: i + 1, kind: 'color', text: c })
    if (jsx) for (const c of copyFindings(line)) problems.push({ line: i + 1, kind: 'copy', text: c })
  })
  return problems
}

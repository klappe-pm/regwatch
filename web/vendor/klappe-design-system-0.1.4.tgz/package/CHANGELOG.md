# Changelog

## 0.1.4

Fixes found while moving verdict and product-feedback onto the package.

### Changed (action may be needed)

- **Global Material UI overrides are opt-in.** A DESIGN.md component no longer restyles every instance of the
  Material UI component it maps to. It styles only what renders through `Part` or `componentSx`. To keep the old
  behaviour for a component, add `scope: global` (or `material-default: true`) to it in DESIGN.md and run `ds sync`.
  Its state components (`-hover`, `-selected` and so on) follow it. Specs written by 0.1.3 have no `global` flag, so
  re-run `ds sync` after upgrading.
- **Component colors are CSS variables.** `{colors.x}` and `{roles.x}` in a component are written to spec.json as
  `var(--ds-role-<role>, <value>)` when a role maps to that color (the role is picked by property: text colors prefer
  `on-*` roles, backgrounds prefer surface and accent roles, borders prefer outline roles), otherwise as
  `var(--ds-color-<name>, <value>)`. They follow dark mode when the app loads `design/ds.css` (or uses a scoped
  provider). `buildSpec(front, { colorRefs: 'value' })` restores resolved values.
- **Spacing unit.** The theme spacing unit is `ds.config.json` `spacingUnit`, else DESIGN.md `spacing.unit` (a length
  or the name of another spacing token), else `spacing.base`, else 8px. It no longer falls back to the first spacing
  entry. `spacing.unit` is not emitted as a `--ds-space-*` token.

### Added

- `createCopy` in `@klappe/design-system/core`, with no React dependency. The React entry re-exports the same function.
  `onMissing` also accepts a function that returns the fallback text.
- `DesignSystemProvider` `onMissing` prop, and `copy` may be a prebuilt `createCopy` function. `CopyProvider` accepts
  either too.
- `DesignSystemProvider` `cssLayer` prop: `true` or `'mui'` puts Material UI styles in the `mui` cascade layer so plain
  app CSS wins; `'tailwind'` also declares `@layer theme, base, mui, components, utilities;`.
- `spacingUnit(spec)` and `TAILWIND_LAYER_ORDER` exports; `lintSource`, `colorFindings` and `copyFindings` in the core
  entry; `selector` and `global` on spec components; `spacingUnit` on the spec.

### Fixed

- `selector` and other metadata keys (`scope`, `material-default`, `description`, `note`, `notes`) no longer reach CSS.
- `ds lint` no longer reports TypeScript generics (`=> Promise<T>`, `api.get<T>(`) as hardcoded copy.
- `ds lint` checks `.html` files, and reports a hex only with a valid length (3, 4, 6 or 8), not followed by identifier
  characters, in a color context. Anchors, ids and selectors (`#add-rule`, `href="#add"`, `querySelector('#add')`) are
  not colors.
- `ds.config.json` `src` entries may be files as well as folders.
- The baseline keeps `box-sizing` working inside `<details>` (CssBaseline and ScopedCssBaseline).
- The core type declarations no longer import a file missing from the package.

---
models: []
providers: [OpenAI]
session-link: ""
date-revised: 2026-10-31
---

# migration-planning

This first delivery provides a compatibility proposal and an impact query. It does not yet provide a visual system picker, real vendor adapters, source rewriting, or experiment assignment. Existing Material rendering remains the production path.

## adapter-and-mapping-contract

Each adapter declares an `id`, exact release `version`, `framework`, `components`, and semantic `tokens`. The host must bind these declarations to the actual installed package and artifact digest. These functions check the supplied declarations; they do not fetch packages or prove the declarations true. No floating package selector should be recorded as the release version.

A component declares a stable adapter-local `id`, a semantic `role`, and explicit arrays of `states`, `slots`, `events`, and `tokenRoles`. A token declares semantic `id`, `type`, and adapter-specific `path`. An explicit mapping declares `from`, `to`, and a boolean `reviewed`. This flag records a supplied mapping review; it is never a runtime approval or a permission grant.

The planner requires the target to preserve every declared source capability. A same-role component is a candidate only. Multiple candidates stay ambiguous; a unique candidate still needs an explicit reviewed mapping. Framework changes require another renderer migration adapter. Split/merge transformations, property/event argument conversion, compound widget equivalence and behavioral certification belong in later adapters.

The default license policy allows `MIT`. A caller can explicitly supply other SPDX identifiers in `allowedLicenses`, such as `Apache-2.0`. A target must supply a matching license identifier and an HTTP(S) evidence URL. This is a policy/evidence presence check. The host owns verification against the exact package, asset licenses and commercial terms. Never use this result as a legal approval.

## synthetic-switch-example

These capability declarations illustrate the contract. They are not validated vendor adapters.

```json
{
  "schemaVersion": 1,
  "source": {
    "id": "custom",
    "version": "fixture-1",
    "framework": "react",
    "components": [{
      "id": "primary-action", "role": "action",
      "states": ["default", "focus", "disabled"],
      "slots": ["label"], "events": ["activate"],
      "tokenRoles": ["action.fill"]
    }],
    "tokens": [{ "id": "action.fill", "type": "color", "path": "roles.primary" }]
  },
  "target": {
    "id": "alternative",
    "version": "fixture-1",
    "framework": "react",
    "license": { "spdx": "MIT", "evidenceUrl": "https://example.com/LICENSE" },
    "components": [{
      "id": "button", "role": "action",
      "states": ["default", "focus", "disabled"],
      "slots": ["label"], "events": ["activate"],
      "tokenRoles": ["action.fill"]
    }],
    "tokens": [{ "id": "action.fill", "type": "color", "path": "theme.primary" }]
  },
  "mappings": [{ "from": "primary-action", "to": "button", "reviewed": true }]
}
```

The result is `ready-for-review` with a typed binding from `roles.primary` to `theme.primary`. Removing the mapping blocks the proposal. Removing `focus` or changing the target token type blocks it even if `reviewed` is true. The planner preserves the source and target version identities in its output.

## impact-contract

`designChangeImpact` accepts a project-scoped snapshot with schema version 1, project identity, source `revision`, declared `coverage` (`complete` or `partial`), components with token-role dependencies, component-to-flow `usages`, and experiments with component, flow and token-role scopes. Experiment status is `draft`, `running`, `completed` or `stopped`.

The change contains explicit `componentIds` and `tokenRoles` arrays. A token change expands to every component declaring that role, then every observed flow using those components. The result retains completed/stopped experiment history as well as running experiments. Matching components, flows or token roles signal possible interaction. This is conservative scope overlap, not a statistical interference or audience-overlap calculation.

`requiresImpactReview` is true for partial coverage, unplaced affected components, or a running experiment with overlapping scope. Empty or unknown selections, duplicate identities, dangling component references, and undeclared experiment token roles throw rather than silently disappearing. A complete snapshot with no flags is still only as current and complete as its provider; the caller must compare its revision to the current repository before acting. This library does not infer freshness from a timestamp.

```json
{
  "schemaVersion": 1,
  "projectId": "demo",
  "revision": "snapshot-1",
  "coverage": "complete",
  "components": [
    { "id": "button", "tokenRoles": ["action.fill"] },
    { "id": "header", "tokenRoles": ["action.fill"] }
  ],
  "usages": [
    { "componentId": "button", "flowId": "signup" },
    { "componentId": "button", "flowId": "checkout" },
    { "componentId": "header", "flowId": "settings" }
  ],
  "experiments": [{
    "id": "EXP-1", "status": "running",
    "componentIds": ["header"], "flowIds": ["settings"],
    "tokenRoles": ["action.fill"]
  }]
}
```

With change `{ "componentIds": [], "tokenRoles": ["action.fill"] }`, impact includes both components, all three flows, and running experiment `EXP-1`. The CLI exits 2 so an automated caller cannot mistake an overlap for an unqualified clear result.

## handoff-to-runtime

Hosts must persist an immutable proposal containing the manifests, their digests, repository base SHA, source revisions, identity, selected policy revision, plan, graph snapshot revision and acceptance criteria. A runtime then evaluates permissions, prepares a branch or isolated worktree, runs the owning repository's generation and verification contracts, records evidence and requests the configured review. These functions deliberately do not implement that authority boundary.

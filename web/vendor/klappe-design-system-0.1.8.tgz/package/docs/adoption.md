# Adopting the design system

Any project can adopt `@klappe/design-system` from its own clone, with no sibling `design-system` checkout. The CLI and the CSS outputs need only Node 20 or later; React and Material UI are optional peers that only the React entry uses.

## one-command-adoption

The release tarball for every version is committed under `releases/` in `klappe-pm/design-system`. Fetch it with the GitHub CLI (`gh api` needs a signed in account, so check `gh auth status` first), install it and run `ds init`, from the project root:

```sh
V=0.1.8; mkdir -p vendor && gh api -H 'Accept: application/vnd.github.raw' "repos/klappe-pm/design-system/contents/releases/klappe-design-system-$V.tgz?ref=main" > "vendor/klappe-design-system-$V.tgz" && npm install --save-dev "./vendor/klappe-design-system-$V.tgz" && npx ds init
```

A released tarball is never changed under the same name, so `ref=main` is stable; pin `ref` to a tag or commit to be strict. Commit `vendor/`, `package.json` and the lockfile, so a fresh clone installs with `npm ci` and no network access to this repository. Never overwrite a vendored tarball in place: a new version gets a new file name, and every `file:` reference and the lockfile change with it.

`ds init` writes, and never overwrites without `--force`:

- `ds.config.json` with `designFile`, `cmsDir`, `out` and `src` (it reads `designFile`, `cmsDir` and `src` from `hub.config.json` when present, and picks up existing `src`, `app`, `components`, `pages` or `web` folders for `ds lint`);
- `DESIGN.md` with a light and dark palette in Material 3 roles, three type styles, spacing, radii and one `button-primary` component;
- `docs/content-management-system/site.md`, one copy document, unless the copy folder already holds documents;
- the `design:sync` and `design:check` scripts in `package.json`, when the project has one (existing scripts are kept);
- then `ds sync`: `design/spec.json`, `design/ds.css`, `design/tailwind.css` and `design/copy.json`.

Running it again changes nothing. Options: `--react` (print the React wiring and the peers the project lacks), `--name <name>`, `--design <file>`, `--cms <dir>`, `--out <dir>`, `--no-scripts`, `--no-sync`, `--force`.

Add `ds check` to CI (or `npm run design:check`) so the outputs never go stale, and `ds lint --strict` once hardcoded colors and copy are moved out.

## plain-html-and-css

No React, no Material UI. Load the tokens and use the variables:

```html
<link rel="stylesheet" href="design/ds.css">
<style>
  .button { background: var(--ds-role-primary); color: var(--ds-role-on-primary); border-radius: var(--ds-radius-medium); padding: var(--ds-space-small) var(--ds-space-regular); }
</style>
```

The dark roles switch on `prefers-color-scheme` and on `data-theme="dark"` on `<html>`. With Tailwind v4, `@import "./design/tailwind.css";` maps the tokens to utilities (`bg-primary`, `text-title-large`, `p-regular`). Copy is a flat map in `design/copy.json`; `createCopy` from `@klappe/design-system/core` reads it in Node or the browser.

## projects-without-node

A Python, Go or Rust project with no `package.json` runs the CLI straight from the vendored tarball; nothing is installed into the project:

```sh
npm exec --yes --package=./vendor/klappe-design-system-0.1.8.tgz -- ds init
npm exec --yes --package=./vendor/klappe-design-system-0.1.8.tgz -- ds check
```

Put the second line in CI. A documentation site or a terminal theme can read `design/ds.css` or `design/spec.json` directly.

## react-and-material-ui

Install the peers, then wrap the app:

```sh
npm install react@^19 react-dom@^19 @mui/material@^9 @emotion/react@^11 @emotion/styled@^11 @emotion/cache@^11
npx ds init --react
```

```tsx
import spec from './design/spec.json'
import copy from './design/copy.json'
import './design/ds.css'
import { DesignSystemProvider, Part } from '@klappe/design-system'

<DesignSystemProvider spec={spec} copy={copy}><Part name="button-primary" /></DesignSystemProvider>
```

Next.js, strict CSP, scoped providers (Obsidian plugins) and dark mode are covered in the [README](../README.md).

## upgrading

Fetch the new tarball with the same command and a new `V`, install it (`npm install --save-dev ./vendor/klappe-design-system-<new>.tgz`), delete the old file from `vendor/`, run `ds sync` and commit the outputs with the lockfile. Read the [changelog](../CHANGELOG.md) for breaking changes first.

## adapter-certification

`ds adapters` prints which stacks are certified, with exact versions and the tests that are their evidence. Token and copy generation (spec, CSS variables, Tailwind, copy) and the React and Material UI renderer are certified. Vue, Angular, Svelte, Web Components and shadcn can read the CSS variables and copy but have no certified renderer (`tokens-only`); SwiftUI, Compose and Flutter are `unsupported`. `ds adapters --check` fails when a dependency moved without new evidence.

## portfolio-adoption

| Project | Stack | Path |
| --- | --- | --- |
| agent-runtime-config control plane (`workbench/control-plane`) | Vite | Adopted on 0.1.3. Upgrade the vendored tarball; its `build` script can call `ds check` instead of `node node_modules/@klappe/design-system/bin/ds.mjs check`. |
| product-feedback | Vite workspace | Adopted on 0.1.5. Upgrade the vendored tarball. |
| regwatch (`web/`) | Next.js, Material UI | Adopted on 0.1.5. Upgrade the vendored tarball inside `web/`. |
| cms | Next.js, React 19 | `npx ds init --react` after installing the tarball; `hub.config.json` has no `designFile`, so the defaults apply. |
| lynter | Obsidian plugin | `npx ds init`, then list Obsidian's prefixes in `hostVariables` (`--background-`, `--text-`, `--interactive-`) and use a scoped provider with `injectTokens="cache"` if it renders React. |
| workflow-kernel | TypeScript library, static `review/` page | `npx ds init` (CSS variables only); link `design/ds.css` from `review/index.html`. |
| stratarc, guardline | Python CLIs and docs | The `npm exec` path above; `ds check` in CI. |

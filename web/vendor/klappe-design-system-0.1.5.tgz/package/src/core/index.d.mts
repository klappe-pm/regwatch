import type { CopyMap, OnMissing, Translate } from './types.mjs'
export type { CopyMap, DesignSpec, OnMissing, SpecComponent, Translate } from './types.mjs'
export { COMPONENT_META_KEYS, M3_ROLES, buildSpec, cssVariables, guessMaterial, specWarnings, tailwindTheme, type BuildSpecOptions } from './spec.mjs'
export declare function createCopy(copy: CopyMap, opts?: { onMissing?: OnMissing }): Translate
export declare function scanDoc(markdown: string): { key: string; value: string }[]
export declare function copyMap(docs: { doc: string; markdown: string }[]): Record<string, string>
export declare function extractEmotionStyles(html: string, sheet: (css: string) => string): string
export declare function cspFindings(html: string): string[]
export declare const LINT_EXTENSIONS: RegExp
export declare function colorFindings(line: string): string[]
export declare function copyFindings(line: string): string[]
export declare function lintSource(text: string, file: string): { line: number; kind: 'color' | 'copy'; text: string }[]

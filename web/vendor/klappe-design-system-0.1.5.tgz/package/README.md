# @klappe/design-system

One design and content framework for every front end. Each project describes its design in `DESIGN.md` frontmatter and
its copy in copy documents; `ds sync` turns them into a spec, CSS variables and a Tailwind theme, and the React entry turns
the spec into a Material UI theme, shared components and the copy runtime.

## Install

The package is private and ships as a tarball. Copy the release into the app and depend on the file:

```sh
cp ../design-system/releases/klappe-design-system-0.1.5.tgz vendor/
npm install --save ./vendor/klappe-design-system-0.1.5.tgz
```

Peer dependencies: `react` and `react-dom` 19, `@mui/material` 9, `@emotion/react` and `@emotion/styled` 11.

Add the generated files to the app's scripts so they never go stale:

```json
{ "scripts": { "dev": "ds sync && next dev", "build": "ds check && next build", "lint": "ds check && ds lint --strict" } }
```

## DESIGN.md

The YAML frontmatter is the source of every token. References like `{colors.pine}` resolve across groups.

```yaml
---
name: Demo
colors:            # named values, any CSS color
  pine: "#143f3d"
  paper: "#f9fbf8"
roles:             # Material 3 roles (primary, on-primary, surface, on-surface, outline...) for the light scheme
  primary: "{colors.pine}"
  on-primary: "{colors.paper}"
  surface: "{colors.paper}"
  on-surface: "{colors.pine}"
rolesDark:         # the same roles for the dark scheme (optional)
  primary: "#d5eb89"
  surface: "#0e302f"
typography:        # each style becomes a Typography variant and --ds-font-<style>-* variables
  body-medium: { fontFamily: "Manrope, sans-serif", fontSize: "1rem", fontWeight: 400, lineHeight: 1.5 }
  title-large: { fontSize: "1.375rem", fontWeight: 500, letterSpacing: "0.01em" }
spacing:
  unit: "8px"      # the theme spacing unit: a length or the name of another spacing token (default: base, then 8px)
  regular: "20px"
rounded:
  medium: "12px"
components:
  button-primary:
    material: Button:contained      # the Material UI component (and variant) Part renders; guessed from the name if absent
    selector: '[data-part~="button-primary"]'  # documentation for the hub's usage scan; never reaches CSS
    scope: global                   # optional: also restyle every MUI Button:contained through the theme
    backgroundColor: "{roles.primary}"
    textColor: "{roles.on-primary}"
    typography: "{typography.body-medium}"
    rounded: "{rounded.medium}"
  button-primary-hover:             # states: -hover, -active, -pressed, -focus, -selected, -disabled
    backgroundColor: "{colors.paper}"
---
```

- **colors, roles, rolesDark.** Roles are the palette. Without `roles`, colors named after a Material role are used.
  Component colors are written as `var(--ds-role-<role>, <value>)`, so they follow dark mode.
- **Fixed colors.** To keep a color that must not follow the scheme (a print preview, a brand mark), write
  `{colors.white!}` for one reference, or add `color-refs: value` to the component for all of its references. Its
  state components (`-hover` and so on) follow it unless they set `color-refs` themselves.
- **typography.** Name styles after the Material 3 roles (`display`, `headline`, `title`, `body`, `label`, each in
  `-small`, `-medium`, `-large`) to get TypeScript support for `<Typography variant="title-large">` with no app code.
- **spacing.unit, rounded.** Every entry becomes `--ds-space-*` or `--ds-radius-*`; `unit` sets `theme.spacing`.
- **components.** Style keys are CSS properties plus `textColor`, `rounded` and `typography`. `material`, `label`,
  `selector`, `scope`, `material-default` and `description` describe the component and never reach CSS. A component
  styles only what renders through `Part`, `useParts` or `partSx`, unless it opts in with `scope: global`.
- **Disabled states.** A `-disabled` component wins. Otherwise interactive parts (Button, ToggleButton, Chip, Tab,
  ListItemButton, MenuItem, IconButton, Fab) get the Material default: on-surface at 38% for content and 12% for
  containers and outlines, built from the role variables.

`ds.config.json` (or `hub.config.json`) in the project root sets `designFile`, `cmsDir`, `out` (default `design`), `src`
for linting, `ignore` and `spacingUnit`. `ds sync` reads custom properties from the project's own CSS to resolve
`var()` aliases in DESIGN.md; it never reads build output (`out`, `.next`, `dist`, `build`, `site`, `coverage`), the
`ignore` paths, or anything git ignores, and `ds lint` skips the same paths.

```json
{ "designFile": "DESIGN.md", "cmsDir": "docs/content-management-system", "src": ["src", "pages"], "ignore": ["src/legacy"], "spacingUnit": "unit" }
```

## CLI

```sh
ds sync    # write design/spec.json, design/ds.css, design/tailwind.css and design/copy.json
ds diff    # list outputs that would change
ds check   # fail when an output is stale (CI, pre-commit, build)
ds lint    # report hardcoded colors and copy in src; --strict fails on findings
ds csp     # after a static export: move Emotion <style> elements into files, fail on inline style or script
```

`ds csp [dir] [--css-dir=_next/static/css]` works on `out` by default. Each page's Emotion styles go into one
`emotion-<hash>.css` file per distinct set, linked where the first `<style>` was, and the command fails on any inline
`<style>`, `style` attribute or inline executable script left (JSON data scripts are allowed).

## React API

```tsx
import spec from '../design/spec.json'
import copy from '../design/copy.json'
import '../design/ds.css'
import { DesignSystemProvider, Part, T, useCopy, useParts } from '@klappe/design-system'

<DesignSystemProvider spec={spec} copy={copy} onMissing="throw" cssLayer>
  <Part name="button-primary" onClick={save} />            {/* MUI Button, styled and labelled from DESIGN.md */}
  <Chip {...useParts(['badge', 'badge-review'], { ml: 1 })} label={<T k="pages.home.badge" />} />
</DesignSystemProvider>
```

- `DesignSystemProvider`: theme, baseline and copy. Props: `spec`, `copy` (map or `createCopy` function), `onMissing`,
  `themeOptions`, `baseline`, `scope` (render inside one element), `persistColorScheme`, `cssLayer`.
- `Part`: renders a DESIGN.md component. It sets `data-part="<name>"` (merged with any `data-part` you pass) and
  `data-component="<name>"`. Switch and Checkbox parts take `checked`, `onChange`, `slotProps` (or `inputProps`) and the
  other control props; with `unlabeled` (or no label in DESIGN.md or children) they render the bare control, e.g.
  `<Part name="switch" unlabeled checked={on} onChange={toggle} slotProps={{ input: { 'aria-labelledby': id } }} />`.
- `useParts(names, ...extraSx)`: `{ 'data-part', sx }` to spread on any MUI component, for several parts at once.
- `T`, `Lines`, `useCopy`, `CopyProvider`, `createCopy`: the copy runtime. `createDesignTheme`, `spacingUnit`,
  `useDesignSpec`, `Page`, `Section`, `SiteHeader`, `SiteFooter` are also exported.
- `@klappe/design-system/styles`: `partSx`, `partProps`, `componentSx`, `disabledSx`, `typeStyle`. Pure functions with
  no `"use client"`, so server components can call them. The main entry re-exports them.
- `@klappe/design-system/core`: `buildSpec`, `cssVariables`, `tailwindTheme`, `createCopy` and the lint helpers, with no
  React dependency.
- `@klappe/design-system/emotion`: `createCspEmotionCache` and `createServerEmotionCache`, see Strict CSP below.
- `@klappe/design-system/typography`: the Typography variant types on their own (`import type {} from
  '@klappe/design-system/typography'`). The main entry loads them already.

## Dark mode

There are two layers, and they switch differently:

- **Token variables** (`design/ds.css`, `--ds-role-*`) switch on `prefers-color-scheme` and on `[data-theme='dark']`.
- **The Material UI palette** (`--mui-palette-*`, `theme.vars`) switches **only** through the `data-theme` attribute on
  `<html>`. The provider sets it after hydration, so server-rendered and static pages paint the light palette until
  then, and a static export without JavaScript never switches.

Set the attribute before first paint. Pick one:

1. **`InitColorSchemeScript`** from `@mui/material/InitColorSchemeScript`, with `attribute="data-theme"` and
   `defaultMode="system"`. It is an inline script, so under a Content Security Policy pass the request's `nonce`.
2. **An external script**, which needs no nonce under `script-src 'self'`. Ship `public/color-scheme.js`:

   ```js
   document.documentElement.setAttribute('data-theme', matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
   ```

   and load it with `<script src="/color-scheme.js"></script>` as the first child of `<body>` (or in `<head>`).
3. **Set it yourself** on the server when you already know the scheme: `<html data-theme="dark">`.

Add `suppressHydrationWarning` to `<html>`, since the attribute differs between server and client.

## Strict CSP

Under `style-src 'self'` (no `'unsafe-inline'`, no nonce) the browser blocks the `<style>` elements Emotion writes. The
package has an Emotion cache that writes Material UI's styles into constructed style sheets adopted by the document
(`document.adoptedStyleSheets`), which the policy does not cover, and puts every rule in the `mui` cascade layer so the
app's own CSS wins. Server-rendered styles are moved into files by `ds csp`.

```tsx
// pages/_app.tsx
import { CacheProvider, type EmotionCache } from '@emotion/react'
import { createCspEmotionCache } from '@klappe/design-system/emotion'
let browserCache: EmotionCache | undefined // one per page; on the server, _document passes its own
export default function App({ Component, pageProps, emotionCache }: AppProps & { emotionCache?: EmotionCache }) {
  return <CacheProvider value={emotionCache ?? (browserCache ??= createCspEmotionCache())}>...</CacheProvider>
}

// pages/_document.tsx
import { documentGetInitialProps } from '@mui/material-nextjs/v16-pagesRouter'
import { createServerEmotionCache } from '@klappe/design-system/emotion'
Document.getInitialProps = (ctx) => documentGetInitialProps(ctx, { emotionCache: createServerEmotionCache() })
```

Then build with `next build && ds csp out`. Both caches take `{ key, layer }` (defaults `'mui'`, `'mui'`; `layer: false`
turns the layer off). Do not also pass `cssLayer` to the provider: the cache already layers every rule.

## Next.js

**App Router.** The package's components are client components, so render the provider from a `"use client"` file and
use it from the root layout. `AppRouterCacheProvider` (`@mui/material-nextjs`) owns the Emotion cache, so pass
`options={{ enableCssLayer: true }}` there instead of `cssLayer`.

```tsx
// app/layout.tsx (server component)
import { headers } from 'next/headers'
import InitColorSchemeScript from '@mui/material/InitColorSchemeScript'
import { AppRouterCacheProvider } from '@mui/material-nextjs/v16-appRouter'
import { Providers } from './providers' // 'use client': <DesignSystemProvider spec={spec} copy={copy}>

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const nonce = (await headers()).get('x-nonce') ?? undefined // set by your middleware's CSP
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <InitColorSchemeScript attribute="data-theme" defaultMode="system" nonce={nonce} />
        <AppRouterCacheProvider options={{ enableCssLayer: true }}>
          <Providers>{children}</Providers>
        </AppRouterCacheProvider>
      </body>
    </html>
  )
}
```

Server components can import `partSx` and `componentSx` from `@klappe/design-system/styles` and `createCopy` from
`@klappe/design-system/core`; anything that needs the provider (`Part`, `useParts`, `T`) stays in client components.

**Pages Router.** Wrap the app in `pages/_app.tsx` with `DesignSystemProvider` (and `AppCacheProvider` from
`@mui/material-nextjs/v16-pagesRouter`), and set the attribute in `pages/_document.tsx`:

```tsx
// nonce: the per-request value your CSP setup passes to the document, if any
<Html lang="en" suppressHydrationWarning>
  <Head />
  <body>
    <InitColorSchemeScript attribute="data-theme" defaultMode="system" nonce={nonce} />
    {/* or, for a static export or a strict CSP: <script src="/color-scheme.js" /> */}
    <Main />
    <NextScript />
  </body>
</Html>
```

With `output: 'export'` there is no per-request nonce, so use the external script.

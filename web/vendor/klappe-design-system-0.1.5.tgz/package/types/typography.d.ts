// DESIGN.md typography roles as Material UI Typography variants, so <Typography variant="title-large"> and
// theme.typography['body-medium'] type check. createDesignTheme registers every DESIGN.md typography style as a
// variant; these are the Material 3 roles (display, headline, title, body, label in small, medium and large) and the
// role names the package maps onto Material UI variants.
//
// Loaded automatically with the package's main entry (through the theme). To load it on its own, add
//   import type {} from '@klappe/design-system/typography'
// to a .d.ts file in the app. Project-specific style names (wordmark, metric and so on) still need the app's own
// augmentation, written the same way.
import '@mui/material/styles'
import '@mui/material/Typography'
import type { CSSProperties } from 'react'

type Role = 'display' | 'headline' | 'title' | 'body' | 'label'
type Size = 'small' | 'medium' | 'large'

export type DesignTypographyVariant = Role | `${Role}-${Size}` | 'subtitle' | 'heading' | 'lead' | 'small' | 'action'

declare module '@mui/material/styles' {
  interface TypographyVariants extends Record<DesignTypographyVariant, CSSProperties> {}
  interface TypographyVariantsOptions extends Partial<Record<DesignTypographyVariant, CSSProperties>> {}
}

declare module '@mui/material/Typography' {
  interface TypographyPropsVariantOverrides extends Record<DesignTypographyVariant, true> {}
}

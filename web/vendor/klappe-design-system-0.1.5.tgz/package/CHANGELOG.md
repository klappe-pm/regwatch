# Changelog

## 0.1.5

Fixes found while moving legal-tbi, verdict and regwatch onto the package.

### Changed (action may be needed)

- **Disabled states follow DESIGN.md.** Interactive parts (Button, IconButton, ToggleButton, Chip, Tab, ListItemButton,
  MenuItem, Fab) get a `&.Mui-disabled` style instead of Material UI's own greys: a `<name>-disabled` component when
  DESIGN.md has one (it wins property by property), otherwise the Material default of the on-surface role at 38% for
  content and 12% for containers and outlines, as `color-mix()` over `var(--ds-role-on-surface)`. The disabled style is
  emitted after the other states, so it wins over `-selected` and `-hover`. App-level disabled patches can go.

### Added

- `Part` sets `data-part="<name>"`, the attribute the hub's usage scan matches (`[data-part~="name"]`), merged with any
  `data-part` tokens the caller passes. `data-component` stays.
- `useParts(names, ...extraSx)` returns `{ 'data-part', sx }` for any Material UI component and several parts at once,
  and the pure `partProps(spec, names, ...extraSx)` behind it.
- `@klappe/design-system/styles`: `partSx`, `partProps`, `componentSx`, `disabledSx`, `typeStyle`, `partTokens` and
  `STATE_SELECTOR` in a module without `"use client"`, so Next.js server components can call them. The main entry
  re-exports the same functions.
- Typography variant types for the Material 3 roles (`display`, `headline`, `title`, `body`, `label`, each also in
  `-small`, `-medium`, `-large`) and `subtitle`, `heading`, `lead`, `small`, `action`. They load with the main entry, or
  on their own from `@klappe/design-system/typography`.
- Strict CSP support: `createCspEmotionCache` (browser: Material UI styles in adopted constructed style sheets, inside
  the `mui` layer, so `style-src 'self'` holds) and `createServerEmotionCache` from `@klappe/design-system/emotion`, and
  `ds csp [dir]`, which moves a static export's Emotion `<style>` elements into style sheet files and fails on any inline
  style or inline executable script. `extractEmotionStyles` and `cspFindings` in the core entry.
- Fixed colors per component: `{colors.x!}` keeps one reference's value, and `color-refs: value` keeps all of a
  component's references (its states follow it), instead of `var(--ds-role-*)`.
- Switch and Checkbox parts pass `checked`, `onChange`, `slotProps` (and `inputProps`, moved to `slotProps.input`) and the
  other control props to the control, and render the bare control with `unlabeled` or when there is no label.
- README: install, DESIGN.md frontmatter, the CLI, the React API, dark mode (the Material UI palette switches only
  through the `data-theme` attribute) and Next.js notes for the App Router and the Pages Router.

### Fixed

- The baseline keeps `box-sizing: border-box` on `<option>` and `<optgroup>` inside `<select>` (CssBaseline and
  ScopedCssBaseline).
- The package lists a README that now exists.
- `ds sync` and `ds lint` no longer read build output as source: `site`, `.vercel` join `out`, `.next`, `dist`,
  `build` and `coverage`, the `ignore` list in `ds.config.json` applies to custom property scanning as well as linting,
  and git-ignored paths are skipped. A `site/` build no longer makes `spec.json` stale.

## 0.1.4

Fixes found while moving verdict and product-feedback onto the package.

### Changed (action may be needed)

- **Global Material UI overrides are opt-in.** A DESIGN.md component no longer restyles every instance of the
  Material UI component it maps to. It styles only what renders through `Part` or `componentSx`. To keep the old
  behaviour for a component, add `scope: global` (or `material-default: true`) to it in DESIGN.md and run `ds sync`.
  Its state components (`-hover`, `-selected` and so on) follow it. Specs written by 0.1.3 have no `global` flag, so
  re-run `ds sync` after upgrading.
- **Component colors are CSS variables.** `{colors.x}` and `{roles.x}` in a component are written to spec.json as
  `var(--ds-role-<role>, <value>)` when a role maps to that color (the role is picked by property: text colors prefer
  `on-*` roles, backgrounds prefer surface and accent roles, borders prefer outline roles), otherwise as
  `var(--ds-color-<name>, <value>)`. They follow dark mode when the app loads `design/ds.css` (or uses a scoped
  provider). `buildSpec(front, { colorRefs: 'value' })` restores resolved values.
- **Spacing unit.** The theme spacing unit is `ds.config.json` `spacingUnit`, else DESIGN.md `spacing.unit` (a length
  or the name of another spacing token), else `spacing.base`, else 8px. It no longer falls back to the first spacing
  entry. `spacing.unit` is not emitted as a `--ds-space-*` token.

### Added

- `createCopy` in `@klappe/design-system/core`, with no React dependency. The React entry re-exports the same function.
  `onMissing` also accepts a function that returns the fallback text.
- `DesignSystemProvider` `onMissing` prop, and `copy` may be a prebuilt `createCopy` function. `CopyProvider` accepts
  either too.
- `DesignSystemProvider` `cssLayer` prop: `true` or `'mui'` puts Material UI styles in the `mui` cascade layer so plain
  app CSS wins; `'tailwind'` also declares `@layer theme, base, mui, components, utilities;`.
- `spacingUnit(spec)` and `TAILWIND_LAYER_ORDER` exports; `lintSource`, `colorFindings` and `copyFindings` in the core
  entry; `selector` and `global` on spec components; `spacingUnit` on the spec.

### Fixed

- `selector` and other metadata keys (`scope`, `material-default`, `description`, `note`, `notes`) no longer reach CSS.
- `ds lint` no longer reports TypeScript generics (`=> Promise<T>`, `api.get<T>(`) as hardcoded copy.
- `ds lint` checks `.html` files, and reports a hex only with a valid length (3, 4, 6 or 8), not followed by identifier
  characters, in a color context. Anchors, ids and selectors (`#add-rule`, `href="#add"`, `querySelector('#add')`) are
  not colors.
- `ds.config.json` `src` entries may be files as well as folders.
- The baseline keeps `box-sizing` working inside `<details>` (CssBaseline and ScopedCssBaseline).
- The core type declarations no longer import a file missing from the package.

# @klappe/design-system

One design and content framework for every front end. Each project describes its design in `DESIGN.md` frontmatter and its copy in copy documents; `ds sync` turns them into a spec, CSS variables and a Tailwind theme, and the React entry turns the spec into a Material UI theme, shared components and the copy runtime.

## Install

The package is MIT licensed (see [LICENSE](LICENSE)). It is not published to the npm registry; it ships as a tarball committed under `releases/`. From the root of any project, with the GitHub CLI signed in, one command vendors it, installs it and writes the starting sources (see [adoption](docs/adoption.md) for plain HTML and CSS, projects without Node, React and every portfolio project):

```sh
V=0.1.9; mkdir -p vendor && gh api -H 'Accept: application/vnd.github.raw' "repos/klappe-pm/design-system/contents/releases/klappe-design-system-$V.tgz?ref=main" > "vendor/klappe-design-system-$V.tgz" && npm install --save-dev "./vendor/klappe-design-system-$V.tgz" && npx ds init
```

Commit `vendor/` with the lockfile so a fresh clone installs with `npm ci`. From a local checkout of this repository, `cp <checkout>/releases/klappe-design-system-0.1.9.tgz vendor/` works the same way.

The CLI, `@klappe/design-system/core`, `@klappe/design-system/node` and the CSS outputs need only Node 20 or later. The React entry needs the peer dependencies `react` and `react-dom` 19, `@mui/material` 9, `@emotion/react`, `@emotion/styled` and `@emotion/cache` 11; they are optional peers, so a project without React installs none of them (`ds init --react` prints the ones a project lacks).

Add the generated files to the app's scripts so they never go stale:

```json
{ "scripts": { "dev": "ds sync && next dev", "build": "ds check && next build", "lint": "ds check && ds lint --strict" } }
```

### pnpm and vendored tarballs

pnpm treats a `file:` tarball like any other dependency, with two settings to get right in `pnpm-workspace.yaml`:

```yaml
packages:
  - apps/*
  - packages/*
minimumReleaseAge: 1440
minimumReleaseAgeExclude:
  # A vendored tarball (vendor/) has no registry publish date, so the age gate would reject it.
  - "@klappe/design-system"
```

- **`minimumReleaseAgeExclude`.** With `minimumReleaseAge` set, pnpm refuses packages without a publish date older than the limit. A vendored tarball has none, so list the package in `minimumReleaseAgeExclude`.
- **Frozen lockfile.** The lockfile records the tarball's integrity hash. Every app (and workspace package) that depends on the package should point at the same file, for example `"@klappe/design-system": "file:../../vendor/klappe-design-system-0.1.9.tgz"` from `apps/*`. After copying a new release into `vendor/`, update every `file:` reference, run `pnpm install` once to rewrite the lockfile, and commit both. CI then runs `pnpm install --frozen-lockfile`, which fails if a reference and the lockfile disagree or the tarball changed without a new lockfile. Never overwrite a tarball in place under the same name: the hash changes and frozen installs fail.
- A workspace package that only re-exports the design system can list it as a peer (`"@klappe/design-system": "*"`) with the same `file:` reference as a dev dependency, so one copy is installed.

npm works the same way: `npm ci` checks the tarball against `package-lock.json`.

## DESIGN.md

The YAML frontmatter is the source of every token. References like `{colors.pine}` resolve across groups.

```yaml
---
name: Demo
colors:            # named values, any CSS color
  pine: "#143f3d"
  paper: "#f9fbf8"
roles:             # Material 3 roles (primary, on-primary, surface, on-surface, outline...) for the light scheme
  primary: "{colors.pine}"
  on-primary: "{colors.paper}"
  surface: "{colors.paper}"
  on-surface: "{colors.pine}"
rolesDark:         # the same roles for the dark scheme (optional)
  primary: "#d5eb89"
  surface: "#0e302f"
typography:        # each style becomes a Typography variant and --ds-font-<style>-* variables
  body-medium: { fontFamily: "Manrope, sans-serif", fontSize: "1rem", fontWeight: 400, lineHeight: 1.5 }
  title-large: { fontSize: "1.375rem", fontWeight: 500, letterSpacing: "0.01em" }
spacing:
  unit: "8px"      # the theme spacing unit: a length or the name of another spacing token (default: base, then 8px)
  regular: "20px"
rounded:
  medium: "12px"
components:
  button-primary:
    material: Button:contained      # the Material UI component (and variant) Part renders; guessed from the name if absent
    selector: '[data-part~="button-primary"]'  # documentation for the hub's usage scan; never reaches CSS
    scope: global                   # optional: also restyle every MUI Button:contained through the theme
    backgroundColor: "{roles.primary}"
    textColor: "{roles.on-primary}"
    typography: "{typography.body-medium}"
    rounded: "{rounded.medium}"
    "& .MuiButton-startIcon":        # nested rules: selectors relative to the component
      marginRight: "4px"
    "@media (max-width: 600px)":    # and media, container and supports queries
      padding: "6px 12px"
  button-primary-hover:             # states: -hover, -active, -pressed, -focus, -selected, -disabled
    backgroundColor: "{colors.paper}"
  button-small:                     # a modifier: combined with a base part, no disabled defaults of its own
    material: Button:contained
    modifier: true
    padding: "2px 8px"
---
```

- **colors, roles, rolesDark.** Roles are the palette. Without `roles`, colors named after a Material role are used. Component colors are written as `var(--ds-role-<role>, <value>)`, so they follow dark mode.
- **Fixed colors.** To keep a color that must not follow the scheme (a print preview, a brand mark), write `{colors.white!}` for one reference, or add `color-refs: value` to the component for all of its references. Its state components (`-hover` and so on) follow it unless they set `color-refs` themselves.
- **var() values.** A `var(--x, fallback)` is a runtime reference and is kept as written. A `var(--x)` without a fallback is an alias: `ds sync` resolves it from the project's own CSS and warns, so every app gets a value. Custom properties the host page defines (Obsidian's `--background-primary`, `--text-normal`) are neither resolved nor reported once their prefixes are listed in `ds.config.json` `hostVariables`.
- **typography.** Name styles after the Material 3 roles (`display`, `headline`, `title`, `body`, `label`, each in `-small`, `-medium`, `-large`) to get TypeScript support for `<Typography variant="title-large">` with no app code.
- **spacing.unit, rounded.** Every entry becomes `--ds-space-*` or `--ds-radius-*`; `unit` sets `theme.spacing`. `spacing.unit` and `ds.config.json` `spacingUnit` take a length or the name of a spacing token, `unit` included, so `"spacingUnit": "unit"` picks up `spacing.unit`.
- **components.** Style keys are CSS properties plus `textColor`, `rounded` and `typography`. `material`, `label`, `selector`, `scope`, `material-default`, `modifier`, `color-refs` and `description` describe the component and never reach CSS. A component styles only what renders through `Part`, `useParts` or `partSx`, unless it opts in with `scope: global`.
- **Nested rules.** A key that starts with `&`, `:`, `.`, `[`, `>` or `@media`, `@container`, `@supports` holds a nested rule, passed into `sx` as is (with `textColor`, `rounded` and references converted as at the top level), up to three levels deep. `ds sync` and `ds check` fail on an object that is not a nested rule, an at-rule without a condition in parentheses, or a selector or value containing `{`, `}` or `;`.
- **Disabled states.** A `-disabled` component wins. Otherwise interactive parts (Button, IconButton, ButtonBase, ToggleButton, Chip, Tab, ListItemButton, MenuItem, Fab) get the Material default: on-surface at 38% for content and 12% for containers and outlines, built from the role variables.
- **Modifier parts.** A component with `modifier: true` (a size or density variant such as `button-small`) is meant to be combined with a base part: `<Part name="button-primary" modifiers={['button-small']}>` or `useParts(['button-primary', 'button-small'])`. Its styles follow the base part's; it gets no disabled default of its own (the base part's applies; an explicit `button-small-disabled` still does), and it never becomes the global look of its Material UI component.

## Config

`ds.config.json` in the project root:

```json
{
  "designFile": "DESIGN.md",
  "cmsDir": "docs/content-management-system",
  "out": "design",
  "src": ["src", "pages"],
  "ignore": ["src/legacy"],
  "spacingUnit": "unit",
  "hostVariables": ["--background-", "--text-", "--interactive-"],
  "files": { "spec": "design/spec.json", "css": "styles/tokens.css" },
  "colorSchemeAttribute": "data-theme"
}
```

- `designFile`, `cmsDir`: the sources. `src`: folders or files `ds lint` reads. `ignore`: paths never read.
- `out`: the folder outputs go to (default `design`). `files`: the path of one output (`spec`, `css`, `tailwind`, `copy`), relative to the root.
- `spacingUnit`: the theme spacing unit, a length or a spacing token name.
- `hostVariables`: prefixes of custom properties the host page defines; kept as written, never reported.
- `colorSchemeAttribute`: the attribute `design/ds.css` switches the dark roles on (default `data-theme`).

**hub.config.json.** When there is no `ds.config.json` key for them, `ds` reads `designFile`, `cmsDir` and `src` from `hub.config.json`, so a project the hub manages needs no second file. Every other key (`out`, `files`, `ignore`, `spacingUnit`, `hostVariables`, `colorSchemeAttribute`) is read from `ds.config.json` only, and `ds.config.json` wins wherever both set a key.

`ds sync` reads custom properties from the project's own CSS to resolve `var()` aliases in DESIGN.md; it never reads build output (`out`, `.next`, `dist`, `build`, `site`, `coverage`), the outputs, the `ignore` paths, or anything git ignores, and `ds lint` skips the same paths.

## CLI

```sh
ds init    # write a starter DESIGN.md, copy document and ds.config.json, then ds sync (--react for the React wiring)
ds sync    # write design/spec.json, design/ds.css, design/tailwind.css and design/copy.json
ds diff    # list outputs that would change
ds check   # fail when an output is stale or DESIGN.md has errors (CI, pre-commit, build)
ds lint    # report hardcoded colors and copy in src; --strict fails on findings
ds csp     # after a static export: move Emotion <style> elements into files, fail on inline style or script
ds adapters  # print the adapter capability matrix as JSON; --check fails when it is stale
ds version # print the installed package version
```

`ds init` never overwrites a file without `--force` and is safe to run again. It reads `designFile`, `cmsDir` and `src` from `hub.config.json` when present and adds `design:sync` and `design:check` scripts to `package.json` without replacing existing ones. Options: `--name`, `--design <file>`, `--cms <dir>`, `--out <dir>`, `--no-scripts`, `--no-sync`.

`ds adapters` lists every adapter with its status (`certified`, `tokens-only`, `unsupported`), what it does and does not do, the exact versions its evidence ran against and the test files that are that evidence. Token and copy generation is certified separately from the React and Material UI renderer; other stacks can read the CSS variables but have no certified renderer. `ds adapters --check` fails when a pinned dependency moved without new evidence or a certified adapter has none.

`sync`, `diff` and `check` take output paths: `--out <dir>` for the folder, and `--spec`, `--css`, `--tailwind`, `--copy <file>` for one file (`--out=web/design` works too). Flags win over `ds.config.json`.

`ds lint` reports hex and `rgb()` colors outside DESIGN.md, and hardcoded copy in JSX: text between tags, string values of `aria-label`, `placeholder`, `title`, `alt` and `label` attributes (and `'aria-label'` keys in `slotProps` or `inputProps`), and template literals as JSX children or in those attributes. It leaves class names, ids, keys, URLs, paths and copy keys alone. Mark a deliberate exception with a comment: `ds-lint-ignore` on the line, `ds-lint-ignore-next-line` on the line before, or `ds-lint-ignore-file` anywhere in the file.

`ds csp [dir] [--css-dir=_next/static/css]` works on `out` by default. Each page's Emotion styles go into one `emotion-<hash>.css` file per distinct set, linked where the first `<style>` was, and the command fails on any inline `<style>`, `style` attribute or inline executable script left (JSON data scripts are allowed).

### As a library

`@klappe/design-system/node` has the same commands as functions, for build scripts and hooks that should not spawn a process. Importing `bin/ds.mjs` no longer runs the command line either.

```js
import { check, loadConfig, outputs, run, sync } from '@klappe/design-system/node'

const { written, warnings, errors } = sync({ root: process.cwd() })
const config = loadConfig(process.cwd(), { out: 'web/design', files: { css: 'web/styles/tokens.css' } })
const { files } = outputs({ root: process.cwd(), config })   // the generated text, nothing written
if (!check({ root: process.cwd(), config }).ok) process.exitCode = 1
process.exitCode = run(['lint', '--strict'])                  // the CLI, returning its exit code
```

It uses Node (`fs`, `child_process`), so it is a separate entry; `@klappe/design-system/core` stays free of Node imports because browsers load it.

## React API

```tsx
import spec from '../design/spec.json'
import copy from '../design/copy.json'
import '../design/ds.css'
import { DesignSystemProvider, Part, T, useCopy, useParts } from '@klappe/design-system'

<DesignSystemProvider spec={spec} copy={copy} onMissing="throw" cssLayer>
  <Part name="button-primary" onClick={save} />            {/* MUI Button, styled and labelled from DESIGN.md */}
  <Part name="button-primary" type="submit" />              {/* type="button" unless you ask for submit */}
  <Chip {...useParts(['badge', 'badge-review'], { ml: 1 })} label={<T k="pages.home.badge" />} />
</DesignSystemProvider>
```

- `DesignSystemProvider`: theme, baseline and copy. Props: `spec`, `copy` (map or `createCopy` function), `onMissing`, `themeOptions`, `baseline`, `scope` (render inside one element), `colorMode`, `persistColorScheme`, `colorSchemeNode`, `colorSchemeSelector`, `injectTokens`, `parts`, `cssLayer`. See Dark mode and Scoped providers.
- `Part`: renders a DESIGN.md component. It sets `data-part="<name>"` (merged with any `data-part` you pass, and the names of any `modifiers`) and `data-component="<name>"`. Button, IconButton and ButtonBase parts render `type="button"` unless you pass `type="submit"` (or `"reset"`), so a part inside a form never submits it by accident. Switch and Checkbox parts take `checked`, `onChange`, `slotProps` (or `inputProps`) and the other control props; with `unlabeled` (or no label in DESIGN.md or children) they render the bare control, e.g. `<Part name="switch" unlabeled checked={on} onChange={toggle} slotProps={{ input: { 'aria-labelledby': id } }} />`.
- `useParts(names, ...extraSx)`: `{ 'data-part', sx }` to spread on any MUI component, for several parts at once.
- `T`, `Lines`, `useCopy`, `CopyProvider`, `createCopy`: the copy runtime. `T` and `useCopy` need a provider: without one `useCopy` throws, and `T` throws unless it has a `fallback` (`<T k="x" fallback="Loading" />`), so a tree rendered outside the provider fails instead of showing raw keys. `createDesignTheme`, `spacingUnit`, `useDesignSpec`, `Page`, `Section`, `SiteHeader`, `SiteFooter` are also exported.
- `@klappe/design-system/styles`: `partSx`, `partProps`, `componentSx`, `disabledSx`, `typeStyle`, `scopedTokenCss`. Pure functions with no `"use client"`, so server components can call them. The main entry re-exports them.
- `@klappe/design-system/core`: `buildSpec`, `cssVariables`, `tailwindTheme`, `createCopy`, `specErrors` and the lint helpers, with no React or Node dependency.
- `@klappe/design-system/node`: the `ds` commands as functions (see As a library).
- `@klappe/design-system/emotion`: `createCspEmotionCache`, `createServerEmotionCache` and `disposeCspEmotionCache`, see Strict CSP below.
- `@klappe/design-system/parts` and `@klappe/design-system/parts/<name>`: Part renderers, see below.
- `@klappe/design-system/typography`: the Typography variant types on their own (`import type {} from '@klappe/design-system/typography'`). The main entry loads them already.

### Parts and bundle size

The main entry's `Part` renders Button, Link, TextField, Chip, Tab, Card, AppBar, ListItemButton, Typography, Checkbox and Switch. Every other Material UI component has a renderer in its own entry point, which imports only that component, so an app bundles only what it renders:

| Entry point | Renderers | `material:` |
| --- | --- | --- |
| `@klappe/design-system/parts/table` | `table`, `tableHead`, `tableBody`, `tableRow`, `tableCell` (all: `tableParts`) | `Table`, `TableHead`, `TableBody`, `TableRow`, `TableCell` |
| `@klappe/design-system/parts/paper` | `paper` | `Paper` (outlined; `Paper:elevation`) |
| `@klappe/design-system/parts/list` | `list`, `listItem` | `List`, `ListItem` |
| `@klappe/design-system/parts/icon-button` | `iconButton` (the label becomes `aria-label`) | `IconButton` |
| `@klappe/design-system/parts/button-base` | `buttonBase` | `ButtonBase` |
| `@klappe/design-system/parts/input-base` | `inputBase` (the label becomes `aria-label`) | `InputBase` |
| `@klappe/design-system/parts/native-select` | `nativeSelect` (options are children) | `NativeSelect`, `NativeSelect:outlined` |
| `@klappe/design-system/parts/alert` | `alert` | `Alert`, `Alert:outlined`, `Alert:filled` |
| `@klappe/design-system/parts/circular-progress` | `circularProgress` (the label becomes `aria-label`) | `CircularProgress` |
| `@klappe/design-system/parts/form-label` | `formLabel` | `FormLabel` |

The 0.1.5 set has entries too (`parts/button`, `parts/link`, `parts/text-field`, `parts/chip`, `parts/tab`, `parts/card`, `parts/app-bar`, `parts/list-item-button`, `parts/typography`, `parts/checkbox`, `parts/switch`). Register renderers for the main `Part` with the provider's `parts` prop (or `<PartRegistry parts={[...]}>` for a subtree), or build a Part of your own that carries nothing else:

```tsx
import { createPart } from '@klappe/design-system/parts'
import { button } from '@klappe/design-system/parts/button'
import { tableParts } from '@klappe/design-system/parts/table'
import { alert } from '@klappe/design-system/parts/alert'

export const Part = createPart([button, alert, ...tableParts])   // or: <DesignSystemProvider parts={[alert, ...tableParts]}>
```

Each entry also exports a single-component Part (`ButtonPart`, `TablePart`, `AlertPart` and so on). A part whose component has no renderer renders a `Box` and, in development, warns with the entry point to import. `useParts` imports no Material UI component at all.

## Dark mode

There are two layers, and they switch differently:

- **Token variables** (`design/ds.css`, `--ds-role-*`) switch on `prefers-color-scheme` and on `[data-theme='dark']`.
- **The Material UI palette** (`--mui-palette-*`, `theme.vars`) switches **only** through the `data-theme` attribute on `<html>`. The provider sets it after hydration, so server-rendered and static pages paint the light palette until then, and a static export without JavaScript never switches.

**Forcing a mode.** `colorMode="light"` or `"dark"` forces that scheme (a public page that stays light, a plugin that follows its host's theme); `"system"` follows the operating system. The provider switches when the prop changes, so `colorMode={host.isDark ? 'dark' : 'light'}` replaces a hand-written `useColorScheme().setMode` effect.

**Remembering the choice.** `persistColorScheme` stores the visitor's choice in localStorage under Material UI's keys; `persistColorScheme={{ key: 'pma-theme' }}` stores the mode under `pma-theme` (and the scheme under `pma-theme-scheme`). Pass the same key to `InitColorSchemeScript` (`modeStorageKey="pma-theme"`) so the first paint reads it.

Set the attribute before first paint. Pick one:

1. **`InitColorSchemeScript`** from `@mui/material/InitColorSchemeScript`, with `attribute="data-theme"` and `defaultMode="system"`. It is an inline script, so under a Content Security Policy pass the request's `nonce`.
2. **An external script**, which needs no nonce under `script-src 'self'`. Ship `public/color-scheme.js`:

   ```js
   document.documentElement.setAttribute('data-theme', matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
   ```

   and load it with `<script src="/color-scheme.js"></script>` as the first child of `<body>` (or in `<head>`).
3. **Set it yourself** on the server when you already know the scheme: `<html data-theme="dark">`.

Add `suppressHydrationWarning` to `<html>`, since the attribute differs between server and client.

`colorSchemeSelector` changes the attribute (`colorSchemeSelector="data-pma-theme"`), or takes a full selector with `%s` for the scheme name. For an unscoped app, set `colorSchemeAttribute` in `ds.config.json` to the same attribute so `design/ds.css` switches on it too.

### Scoped providers

With `scope="preview"` the theme variables, the token variables and the baseline stay inside `<div id="preview">`. Dark mode is scoped as well:

- The color-scheme attribute goes on the scope's element by default (`colorSchemeNode="scope"`), and both the dark palette (`#preview[data-theme="dark"]`) and the dark token roles (`#preview[data-theme='dark']`) are tied to it, so a preview never marks or reads the page root. `colorMode` sets the scheme per scope.
- `colorSchemeNode="root"` puts the attribute on `<html>` and switches on `[data-theme="dark"] #preview` instead (the scope follows the page); an element (a popout window's root) works the same way.
- `colorSchemeSelector="data-pwb-color-scheme"` uses another attribute name, so nothing else on the page reads it.

The scoped provider writes the token variables in an inline `<style>` element. Hosts that forbid `<style>` elements (Obsidian plugins) or a strict `style-src` pick another way with `injectTokens`:

- `injectTokens="cache"` hands them to the Emotion cache in use as global styles. With `createCspEmotionCache` they end up in an adopted constructed style sheet, like Material UI's own styles.
- `injectTokens={false}` leaves them out; the host loads them itself. `scopedTokenCss(spec, { scope })` from `@klappe/design-system/styles` gives the same CSS for a plugin's `styles.css` or a sheet of its own.

```tsx
// An Obsidian view: no <style> elements, the host's theme, styles that beat Obsidian's unlayered CSS.
const cache = createCspEmotionCache({ key: 'pwb', layer: false, specificity: 3, document: containerEl.ownerDocument })
<CacheProvider value={cache}>
  <DesignSystemProvider spec={spec} copy={t} scope={id} colorMode={isDark ? 'dark' : 'light'} injectTokens="cache">
    {view}
  </DesignSystemProvider>
</CacheProvider>
```

## CSS layers

`cssLayer` (and `createCspEmotionCache`, and `enableCssLayer` on the Next.js cache providers) put Material UI's styles, part styles included, in the `mui` cascade layer. An unlayered rule beats every layered rule regardless of specificity, so the app's own CSS wins over Material UI. That cuts both ways: an unlayered reset such as `p { margin: 0 }` or `button { font: inherit }` also beats the part styles from DESIGN.md.

Put the app's CSS in a layer of its own, declared after `mui` only where it should win, and keep resets below it:

```css
/* app.css, loaded once before the rest */
@layer reset, mui, app;

@layer reset {
  p, h1, h2, h3 { margin: 0; }
}
@layer app {
  .page { display: grid; gap: var(--ds-space-regular); }
}
```

- Resets go in a layer listed **before** `mui`, so part styles win over them.
- Layout and page CSS go in `app`, after `mui`, when it should win over Material UI; the order in the `@layer` statement decides, not the file order.
- With Tailwind v4, use `TAILWIND_LAYER_ORDER` (`@layer theme, base, mui, components, utilities;`, or `cssLayer="tailwind"`): Tailwind's preflight sits in `base`, below `mui`.
- Where the host's CSS is unlayered and cannot be moved (Obsidian), turn the layer off and raise specificity on the cache instead (`createCspEmotionCache({ layer: false, specificity: 3 })`).

## Strict CSP

Under `style-src 'self'` (no `'unsafe-inline'`, no nonce) the browser blocks the `<style>` elements Emotion writes. The package has an Emotion cache that writes Material UI's styles into constructed style sheets adopted by the document (`document.adoptedStyleSheets`), which the policy does not cover, and puts every rule in the `mui` cascade layer so the app's own CSS wins. Server-rendered styles are moved into files by `ds csp`.

```tsx
// pages/_app.tsx
import { CacheProvider, type EmotionCache } from '@emotion/react'
import { createCspEmotionCache } from '@klappe/design-system/emotion'
let browserCache: EmotionCache | undefined // one per page; on the server, _document passes its own
export default function App({ Component, pageProps, emotionCache }: AppProps & { emotionCache?: EmotionCache }) {
  return <CacheProvider value={emotionCache ?? (browserCache ??= createCspEmotionCache())}>...</CacheProvider>
}

// pages/_document.tsx
import { documentGetInitialProps } from '@mui/material-nextjs/v16-pagesRouter'
import { createServerEmotionCache } from '@klappe/design-system/emotion'
Document.getInitialProps = (ctx) => documentGetInitialProps(ctx, { emotionCache: createServerEmotionCache() })
```

Then build with `next build && ds csp out`. Both caches take `{ key, layer, specificity }` (defaults `'mui'`, `'mui'`, none; `layer: false` turns the layer off). Do not also pass `cssLayer` to the provider: the cache already layers every rule.

- `document`: the document whose `adoptedStyleSheets` get the styles (default: the global one). A popout window needs a cache of its own with its document, since a constructed sheet can only be adopted by the window that made it.
- `specificity`: a number repeats each class selector (`3`: `.pwb-x.pwb-x.pwb-x`), a string prefixes every rule (`'.pwb-root'`: `.pwb-root .pwb-x`). Use it with `layer: false` to beat unlayered host CSS. Global styles keep their selectors.
- `disposeCspEmotionCache(cache)` takes every adopted sheet of the cache off its document, for a plugin that unloads.

## Next.js

**App Router.** The package's components are client components, so render the provider from a `"use client"` file and use it from the root layout. `AppRouterCacheProvider` (`@mui/material-nextjs`) owns the Emotion cache, so pass `options={{ enableCssLayer: true }}` there instead of `cssLayer`.

```tsx
// app/layout.tsx (server component)
import { headers } from 'next/headers'
import InitColorSchemeScript from '@mui/material/InitColorSchemeScript'
import { AppRouterCacheProvider } from '@mui/material-nextjs/v16-appRouter'
import { Providers } from './providers' // 'use client': <DesignSystemProvider spec={spec} copy={copy}>

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const nonce = (await headers()).get('x-nonce') ?? undefined // set by your middleware's CSP
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <InitColorSchemeScript attribute="data-theme" defaultMode="system" nonce={nonce} />
        <AppRouterCacheProvider options={{ enableCssLayer: true }}>
          <Providers>{children}</Providers>
        </AppRouterCacheProvider>
      </body>
    </html>
  )
}
```

Server components can import `partSx` and `componentSx` from `@klappe/design-system/styles` and `createCopy` from `@klappe/design-system/core`; anything that needs the provider (`Part`, `useParts`, `T`) stays in client components.

**Pages Router.** Wrap the app in `pages/_app.tsx` with `DesignSystemProvider` (and `AppCacheProvider` from `@mui/material-nextjs/v16-pagesRouter`), and set the attribute in `pages/_document.tsx`:

```tsx
// nonce: the per-request value your CSP setup passes to the document, if any
<Html lang="en" suppressHydrationWarning>
  <Head />
  <body>
    <InitColorSchemeScript attribute="data-theme" defaultMode="system" nonce={nonce} />
    {/* or, for a static export or a strict CSP: <script src="/color-scheme.js" /> */}
    <Main />
    <NextScript />
  </body>
</Html>
```

With `output: 'export'` there is no per-request nonce, so use the external script.

## design-system-switch-planning

Since 0.1.7 the core has `planDesignSystemSwitch(input)` and `designChangeImpact(snapshot, change)`. Both are pure JSON-record functions without React, filesystem, provider, persistence or execution dependencies. They can be called from an editor, an API adapter or an agent tool.

```js
import { planDesignSystemSwitch, designChangeImpact } from '@klappe/design-system/core'

const proposal = planDesignSystemSwitch(manifest)
const impact = designChangeImpact(snapshot, {
  componentIds: ['checkout-action'],
  tokenRoles: ['action.fill'],
})
```

Command line equivalents:

```sh
ds plan-switch /absolute/path/to/manifest.json
ds impact /absolute/path/to/snapshot.json /absolute/path/to/change.json
```

Inputs are explicit JSON files, each limited to 4 MiB. Output is JSON. Exit 0 indicates readiness for review, exit 2 indicates compatibility blockers or impact-review flags, and exit 1 indicates invalid input. No command changes a project, calls a provider, runs an experiment or creates a Git commit. A ready plan does not certify implementation behavior, accessibility, licensing or authority to publish.

The [contract and walkthrough](docs/migration-planning.md) include a complete synthetic example. The [research and current-state assessment](https://github.com/klappe-pm/design-system/blob/main/docs/research/design-control-plane.md) explain the architecture and available tools. The [roadmap](https://github.com/klappe-pm/design-system/blob/main/docs/plans/design-control-plane.md) assigns the remaining visual editor, source-write, graph and experimentation work to the existing projects.

## development

```sh
npm ci
npm test
npm run typecheck
npm run build
npm run test:consumer   # pack, install into fresh plain, no-package.json and React projects, run ds init
npm run check:release   # releases/ holds exactly one tarball, for this version, and its name matches its version
```

To release a version, bump `package.json`, move the changelog's Unreleased entries under it, remove the previous release's tarball from `releases/`, run `npm run release` (build and pack into `releases/`) and `node scripts/check-releases.mjs --fresh`, and commit the tarball. `releases/` on `main` holds only the current release; an earlier tarball stays in the history of the commit that released it. A released tarball is never rebuilt under the same name.

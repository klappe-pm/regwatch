# Changelog

## 0.1.9

### Changed

- The packed README, changelog and docs no longer name private projects, clients or local paths, and carry no session provenance frontmatter. The README prose is one paragraph per line.
- **Only the current release ships.** `releases/` holds the 0.1.9 tarball alone; the 0.1.3 to 0.1.8 tarballs are removed from the tree and stay in the history of the commits that released them. `npm run check:release` fails when `releases/` holds a tarball for any other version. Projects on an earlier release upgrade to 0.1.9; no API changed.
- The README and the [adoption guide](docs/adoption.md) adoption commands fetch 0.1.9.

## 0.1.8

### Changed

- **MIT license.** The package is licensed under the MIT license (copyright 2026 Kevin Lappe): `LICENSE` is added and ships in the tarball, and `package.json` declares `"license": "MIT"` in place of `UNLICENSED`. The package is still not published to the npm registry; it ships as the tarball under `releases/`.
- The README and the [adoption guide](docs/adoption.md) no longer describe the package or the repository as private, and their adoption commands fetch 0.1.8.

## 0.1.7

Adoption without a sibling checkout, for projects with or without React.

### Added

- **`ds init`.** Writes a starter `DESIGN.md` (Material 3 roles with a dark scheme, type, spacing, radii and one button), one copy document and `ds.config.json`, adds `design:sync` and `design:check` scripts to `package.json`, and runs `ds sync`. It never overwrites a file without `--force`, reads `hub.config.json`, and with `--react` prints the provider wiring and the peers the project lacks.
- **Optional peers.** React, Material UI and Emotion are optional peer dependencies, so a plain HTML and CSS project (or a project without Node, through `npm exec --package=<tarball>`) installs the CLI and the CSS outputs without them. React projects install them as before.
- **`ds adapters` and `ds adapters --check`.** The adapter capability matrix (also `ADAPTERS`, `adapterMatrix` and `adapterFreshness` from the core entry): status, capabilities, unsupported transformations, exact verified versions and the evidence tests per adapter. Token and copy generation and the React and Material UI renderer are certified; Vue, Angular, Svelte, Web Components and shadcn are tokens-only; SwiftUI, Compose and Flutter are unsupported. The check fails when a dependency pin moved without new evidence.
- **`ds version`.** Prints the installed package version.
- **Adoption guide** ([docs/adoption.md](docs/adoption.md)): one command that fetches the committed tarball with the GitHub CLI, installs it and runs `ds init`, plus the paths for plain CSS, non-Node and React projects.
- **Installed-consumer tests** (`npm run test:consumer`) and a release consistency check (`npm run check:release`, `--fresh` compares the committed tarball with a fresh pack).
- Add framework-neutral migration planning and component/flow experiment impact queries to the core entry point. Explicit reviewed mappings, capability checks, typed token bindings, supplied license evidence, incomplete coverage and experiment overlap remain visible in the result. These functions do not authorize or apply changes.
- Add JSON-only `ds plan-switch` and `ds impact` commands. Exit 0 means a plan is ready for review or an impact query has no review flags; exit 2 means review blockers; exit 1 means invalid input. Existing generation and rendering behavior is unchanged.
- Document the design control plane research, current implementation gaps and sequenced cross-project backlog.

## 0.1.6

Fixes found while moving nine applications, regwatch among them, onto the package. Each app had worked around them.

### Breaking

- **`T` and `useCopy` need a provider.** Without a `CopyProvider` or `DesignSystemProvider` above them, `useCopy` throws
  and `T` throws unless it has a `fallback`. Before, both silently rendered the key. Render the tree inside the
  provider, or give `T` a `fallback`.
- **`var(--x, fallback)` stays as written.** `ds sync` used to collapse a `var()` with a fallback to the fallback (or to
  the project's own value of `--x`). A `var()` with a fallback is now a runtime reference and is kept; a `var()`
  without one still resolves from the project's CSS. Run `ds sync` and review `spec.json` and `ds.css` if DESIGN.md uses
  fallbacks.
- **Scoped dark mode is scoped.** A provider with `scope` puts the color-scheme attribute on the scope's element and
  switches its dark palette on `#<scope>[data-theme="dark"]` (it was `[data-theme="dark"]` on `<html>`, which never
  reached the scope's own light variables). Pass `colorSchemeNode="root"` to keep the attribute on `<html>`; it then
  switches on `[data-theme="dark"] #<scope>`. Scoped providers also get their own color scheme context
  (`disableNestedContext`). Apps that set `themeOptions.cssVariables.colorSchemeSelector` themselves keep the old node.
- **`ds sync` and `ds check` fail on malformed components.** A DESIGN.md component value that is an object but not a
  nested rule (it used to become `"[object Object]"`), an at-rule without a condition, or a value containing `{`, `}`
  or `;` is an error: `ds sync` writes nothing and `ds check` exits 1.
- **`ds lint` reports more copy.** Hardcoded text in `aria-label`, `placeholder`, `title`, `alt` and `label` attributes
  and in JSX template literals is now a finding, so `ds lint --strict` can fail where it passed. Move the text to the
  copy documents or mark the line with `ds-lint-ignore`.

### Added

- **More Part components, without bundling every Material UI component.** Renderers for Table, TableHead, TableBody,
  TableRow, TableCell, Paper, List, ListItem, IconButton, ButtonBase, InputBase, NativeSelect, Alert,
  CircularProgress and FormLabel, each in its own entry point (`@klappe/design-system/parts/table`, `parts/alert` and
  so on, plus `parts/button` and the rest of the 0.1.5 set). Register them with the provider's `parts` prop or
  `<PartRegistry>`, or build a Part that carries only what an app renders with `createPart([...])` from
  `@klappe/design-system/parts`. The main `Part` still renders the 0.1.5 set and imports nothing more; `useParts` moved
  to a module with no Material UI component imports.
- **Button `type`.** Button, IconButton and ButtonBase parts render `type="button"` unless the caller passes
  `type="submit"` (or `"reset"`); the prop is typed and documented, and input parts still take any input type
  (`"email"`, `"search"`).
- **Nested rules in DESIGN.md components.** Keys starting with `&`, `:`, `.`, `[`, `>`, `@media`, `@container` or
  `@supports` hold nested rules that reach `sx` as nested objects, with `textColor`, `rounded` and references converted.
  `specErrors(front)` in the core entry validates them; `ds sync` and `ds check` report the errors.
- **`colorMode`** on the provider: `'light'` or `'dark'` forces the scheme, `'system'` follows the operating system,
  and a change of the prop switches it.
- **`persistColorScheme={{ key }}`** stores the mode under a key of your choice (and the scheme under `<key>-scheme`, or
  `colorSchemeKey`).
- **`colorSchemeNode`** (`'scope'`, `'root'` or an element) chooses which element gets the color-scheme attribute;
  `'scope'` is the default with `scope`. **`colorSchemeSelector`** changes the attribute or takes a full selector.
  `cssVariables(spec, { selector, colorSchemeTarget, attribute })` and `scopedTokenCss(spec, { scope })` write the
  matching token CSS, and `ds.config.json` `colorSchemeAttribute` sets the attribute `design/ds.css` switches on.
- **`injectTokens`** on the provider: `'cache'` hands the scoped token variables to the Emotion cache as global styles
  (adopted constructed sheets with `createCspEmotionCache`, so no `<style>` element), `false` leaves them out.
- **CSP cache options.** `createCspEmotionCache({ document })` adopts sheets into another document (Obsidian popout
  windows), constructing them in that document's window. `specificity` (both caches) repeats class selectors (`3`) or
  prefixes every rule with a selector (`'.root'`) to beat unlayered host CSS without a layer.
  `disposeCspEmotionCache(cache)` takes the cache's sheets off the document.
- **Host variables.** `ds.config.json` `hostVariables` lists custom property prefixes the host page defines
  (`--background-`, `--text-`); `var()` references to them are kept and never reported. `buildSpec` and `specWarnings`
  take `hostVariables` too. A `var()` with a fallback is no longer reported either.
- **`ds` as a library.** `@klappe/design-system/node` exports `sync`, `check`, `outputs`, `lint`, `csp`, `loadConfig`,
  `outputPaths` and `run`. `bin/ds.mjs` is a thin wrapper that runs only when executed, so importing it runs nothing.
  The core entry stays free of Node imports.
- **Output paths.** `ds sync`, `diff` and `check` take `--out <dir>` and `--spec`, `--css`, `--tailwind`, `--copy <file>`;
  `ds.config.json` takes `files: { spec, css, tailwind, copy }`.
- **Copy checks in `ds lint`** for copy attributes and JSX template literals (see Breaking), with low false positives:
  class names, ids, keys, URLs, paths and copy keys are not reported. `ds-lint-ignore`, `ds-lint-ignore-next-line` and
  `ds-lint-ignore-file` comments mark exceptions. `attributeCopyFindings` in the core entry.
- **Modifier parts.** `modifier: true` on a DESIGN.md component (a size variant such as `button-small`) makes it a
  modifier: no disabled default of its own, never the global look of its Material UI component. `Part` takes
  `modifiers={['button-small']}`; `useParts` and `partProps` combine them as more names.
- **README:** pnpm with vendored tarballs (`minimumReleaseAgeExclude`, `--frozen-lockfile`), CSS layers and unlayered
  resets (`@layer reset, mui, app`), scoped providers, the parts entry points, the library entry and the config keys.

### Fixed

- **`spacingUnit: "unit"`** resolved to the literal string `"unit"`, because `unit` was removed from the spacing tokens
  before the name was looked up. Names now resolve among every spacing token (chains such as `unit: base` included)
  before `unit` is left out of the emitted tokens.
- **`hub.config.json`** `designFile` and `src` are read (the README said so, but only `cmsDir` was); `ds.config.json`
  still wins.
- **Missing provider errors.** `useDesignSpec`, `useParts` and `Part` name the caller, the provider to add, the pure
  alternative (`partProps(spec, ...)`) and the duplicate-package case.
- The CSP cache's main sheet leaves the document when it is flushed, not only the global sheets.

## 0.1.5

Fixes found while moving three applications, regwatch among them, onto the package.

### Changed (action may be needed)

- **Disabled states follow DESIGN.md.** Interactive parts (Button, IconButton, ToggleButton, Chip, Tab, ListItemButton,
  MenuItem, Fab) get a `&.Mui-disabled` style instead of Material UI's own greys: a `<name>-disabled` component when
  DESIGN.md has one (it wins property by property), otherwise the Material default of the on-surface role at 38% for
  content and 12% for containers and outlines, as `color-mix()` over `var(--ds-role-on-surface)`. The disabled style is
  emitted after the other states, so it wins over `-selected` and `-hover`. App-level disabled patches can go.

### Added

- `Part` sets `data-part="<name>"`, the attribute the hub's usage scan matches (`[data-part~="name"]`), merged with any
  `data-part` tokens the caller passes. `data-component` stays.
- `useParts(names, ...extraSx)` returns `{ 'data-part', sx }` for any Material UI component and several parts at once,
  and the pure `partProps(spec, names, ...extraSx)` behind it.
- `@klappe/design-system/styles`: `partSx`, `partProps`, `componentSx`, `disabledSx`, `typeStyle`, `partTokens` and
  `STATE_SELECTOR` in a module without `"use client"`, so Next.js server components can call them. The main entry
  re-exports the same functions.
- Typography variant types for the Material 3 roles (`display`, `headline`, `title`, `body`, `label`, each also in
  `-small`, `-medium`, `-large`) and `subtitle`, `heading`, `lead`, `small`, `action`. They load with the main entry, or
  on their own from `@klappe/design-system/typography`.
- Strict CSP support: `createCspEmotionCache` (browser: Material UI styles in adopted constructed style sheets, inside
  the `mui` layer, so `style-src 'self'` holds) and `createServerEmotionCache` from `@klappe/design-system/emotion`, and
  `ds csp [dir]`, which moves a static export's Emotion `<style>` elements into style sheet files and fails on any inline
  style or inline executable script. `extractEmotionStyles` and `cspFindings` in the core entry.
- Fixed colors per component: `{colors.x!}` keeps one reference's value, and `color-refs: value` keeps all of a
  component's references (its states follow it), instead of `var(--ds-role-*)`.
- Switch and Checkbox parts pass `checked`, `onChange`, `slotProps` (and `inputProps`, moved to `slotProps.input`) and the
  other control props to the control, and render the bare control with `unlabeled` or when there is no label.
- README: install, DESIGN.md frontmatter, the CLI, the React API, dark mode (the Material UI palette switches only
  through the `data-theme` attribute) and Next.js notes for the App Router and the Pages Router.

### Fixed

- The baseline keeps `box-sizing: border-box` on `<option>` and `<optgroup>` inside `<select>` (CssBaseline and
  ScopedCssBaseline).
- The package lists a README that now exists.
- `ds sync` and `ds lint` no longer read build output as source: `site`, `.vercel` join `out`, `.next`, `dist`,
  `build` and `coverage`, the `ignore` list in `ds.config.json` applies to custom property scanning as well as linting,
  and git-ignored paths are skipped. A `site/` build no longer makes `spec.json` stale.

## 0.1.4

Fixes found while moving two applications, product-feedback among them, onto the package.

### Changed (action may be needed)

- **Global Material UI overrides are opt-in.** A DESIGN.md component no longer restyles every instance of the
  Material UI component it maps to. It styles only what renders through `Part` or `componentSx`. To keep the old
  behaviour for a component, add `scope: global` (or `material-default: true`) to it in DESIGN.md and run `ds sync`.
  Its state components (`-hover`, `-selected` and so on) follow it. Specs written by 0.1.3 have no `global` flag, so
  re-run `ds sync` after upgrading.
- **Component colors are CSS variables.** `{colors.x}` and `{roles.x}` in a component are written to spec.json as
  `var(--ds-role-<role>, <value>)` when a role maps to that color (the role is picked by property: text colors prefer
  `on-*` roles, backgrounds prefer surface and accent roles, borders prefer outline roles), otherwise as
  `var(--ds-color-<name>, <value>)`. They follow dark mode when the app loads `design/ds.css` (or uses a scoped
  provider). `buildSpec(front, { colorRefs: 'value' })` restores resolved values.
- **Spacing unit.** The theme spacing unit is `ds.config.json` `spacingUnit`, else DESIGN.md `spacing.unit` (a length
  or the name of another spacing token), else `spacing.base`, else 8px. It no longer falls back to the first spacing
  entry. `spacing.unit` is not emitted as a `--ds-space-*` token.

### Added

- `createCopy` in `@klappe/design-system/core`, with no React dependency. The React entry re-exports the same function.
  `onMissing` also accepts a function that returns the fallback text.
- `DesignSystemProvider` `onMissing` prop, and `copy` may be a prebuilt `createCopy` function. `CopyProvider` accepts
  either too.
- `DesignSystemProvider` `cssLayer` prop: `true` or `'mui'` puts Material UI styles in the `mui` cascade layer so plain
  app CSS wins; `'tailwind'` also declares `@layer theme, base, mui, components, utilities;`.
- `spacingUnit(spec)` and `TAILWIND_LAYER_ORDER` exports; `lintSource`, `colorFindings` and `copyFindings` in the core
  entry; `selector` and `global` on spec components; `spacingUnit` on the spec.

### Fixed

- `selector` and other metadata keys (`scope`, `material-default`, `description`, `note`, `notes`) no longer reach CSS.
- `ds lint` no longer reports TypeScript generics (`=> Promise<T>`, `api.get<T>(`) as hardcoded copy.
- `ds lint` checks `.html` files, and reports a hex only with a valid length (3, 4, 6 or 8), not followed by identifier
  characters, in a color context. Anchors, ids and selectors (`#add-rule`, `href="#add"`, `querySelector('#add')`) are
  not colors.
- `ds.config.json` `src` entries may be files as well as folders.
- The baseline keeps `box-sizing` working inside `<details>` (CssBaseline and ScopedCssBaseline).
- The core type declarations no longer import a file missing from the package.
